from flask import Flask, render_template, request
import sqlite3 as sql
app = Flask(__name__)

@app.route("/",methods=['GET','POST'])
def home():
    return render_template("home.html")

@app.route("/course")
def course():
    return render_template("course.html")

@app.route("/register", methods=["GET","POST"])
def register():
    return render_template("register.html")

@app.route('/addrec',methods = ['POST', 'GET'])
def addrec():
  if request.method == 'POST':
     try:
         name = request.form['name']
         addr = request.form['add']
         cont = request.form['contact']
         
         with sql.connect("database.db") as con:
            cur = con.cursor()
            
            cur.execute("INSERT INTO register (name,addr,cont) VALUES (?,?,?)",(name,addr,cont) )
            
            con.commit()
            msg = "Record successfully added"
     except:
         con.rollback()
         msg = "error in insert operation"
      
     finally:
        return render_template("result.html",msg = msg)
        con.close()


@app.route('/list')
def list():
   con = sql.connect("database.db")
   con.row_factory = sql.Row
   
   cur = con.cursor()
   cur.execute("select * from register")
   
   rows = cur.fetchall();
   return render_template("list.html",rows = rows)

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contact")
def contact():
    return render_template("contact.html")

@app.route("/mscit")
def mscit():
    return render_template("mscit.html")

@app.route("/adca")
def adca():
    return render_template("adca.html")

@app.route("/tally")
def tally():
    return render_template("tally.html")

@app.route("/programming")
def programming():
    return render_template("programming.html")




if __name__== "__main__":
    app.run(debug = True)

