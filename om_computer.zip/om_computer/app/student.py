import sqlite3

conn = sqlite3.connect('database.db')
print "Opened database successfully";

conn.execute('CREATE TABLE register (name Text, addr Text, cont INT)')
print "Table created successfully";
conn.close()
